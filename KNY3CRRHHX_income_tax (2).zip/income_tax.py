while True:
    try:
        print("Enter only positive Integers")
        income = int(input("Please enter your taxable income in India: "))
    except ValueError:
        print("Sorry, We didn't understand that please enter taxable income as a number")
        continue
    else:
        break
a =  250000 
# deducted 50000 from the annual income
final_income = income-50000
# if the income is below 250000 then the tax is 0
if final_income<=250000:
    print("0")

first_tax = final_income>250000 and final_income<=500000
# if the income is between 250000 and 500000 then the tax is
if first_tax:
    print(int((final_income-250000)*5/100))
    
    
second_tax = final_income>500000 and final_income<=750000
# if the income is between 500000 and 750000 then the tax is
if second_tax:
    print(int(((final_income-500000)*10/100) + a* (5/100)))


third_tax = final_income > 750000 and final_income<=1000000
# if the income is between 500000 and 750000 then the tax is
if third_tax:
    print(int((final_income - 750000) * 15/100 + a* (10/100) + a* (5/100)))


fourth_tax = final_income > 1000000 and final_income<= 1250000
# if the income is between 750000 and 1000000 then the tax is
if fourth_tax:
    print(int(((final_income-1000000)*20/100+ a *(10/100) + a* (5/100) + a * (15/100))))


fifth_tax = final_income > 1250000 and final_income <= 1500000
# if the income is between 1000000 and 1500000 then the tax is
if fifth_tax:
    print(int((final_income - 1250000) * 25/100 + a* (10/100) + a* (5/100) + a * (15/100)+a*(20/100) ))

last_tax = final_income>1500000
# if the income is greater than 1500000 then the tax is
if last_tax :
    print(int((final_income-1500000)*30/100 +  a * (10/100) + a *(5/100) + a * (15/100)+a*(20/100) + a*(25/100)))